const products = [
  { id: "dress", name: "Noir Midi Dress", category: "women", type: "Women · Occasion", price: 2499, badge: "New" },
  { id: "blazer", name: "Ivory Tailored Blazer", category: "women", type: "Women · Workwear", price: 3299, badge: "Dyaana edit" },
  { id: "coord", name: "Monochrome Co-ord", category: "women", type: "Women · Co-ords", price: 2899, badge: "New" },
  { id: "kurti", name: "Ivory Line Kurti", category: "women", type: "Women · Ethnic", price: 1899, badge: "Limited" },
  { id: "trousers", name: "Black Tailored Trousers", category: "women", type: "Women · Bottoms", price: 1799 },
  { id: "shirt", name: "Midnight Shirt", category: "men", type: "Men · Shirts", price: 1699 },
  { id: "earrings", name: "Sculpted Drop Earrings", category: "jewellery", type: "Jewellery · Earrings", price: 899, badge: "Women first" },
  { id: "necklace", name: "Fine Circle Necklace", category: "jewellery", type: "Jewellery · Necklace", price: 1099 }
];

const relovePiece = { id: "relove-preview", name: "Relove Occasion Piece", category: "relove", type: "Relove · Preview flow", price: 0 };
const bag = [];
let activeFilter = "all";

const money = value => new Intl.NumberFormat("en-IN", { style: "currency", currency: "INR", maximumFractionDigits: 0 }).format(value);
const grid = document.querySelector("#productGrid");
const toast = document.querySelector("#toast");
const overlay = document.querySelector("#overlay");
const bagDrawer = document.querySelector("#bagDrawer");
const sellModal = document.querySelector("#sellModal");
const searchPanel = document.querySelector("#searchPanel");

function productCard(product) {
  const card = document.createElement("article");
  card.className = "product-card";
  card.dataset.category = product.category;
  card.innerHTML = `
    <div class="product-visual" role="img" aria-label="Reserved slot for an original photograph of ${product.name}" tabindex="0">
      ${product.badge ? `<span class="product-badge">${product.badge}</span>` : ""}
      <button class="wishlist" aria-label="Save ${product.name}" title="Save item">♡</button>
      <div class="photo-slot">Original product photo<small>${product.name}</small></div>
    </div>
    <div class="product-info">
      <h3>${product.name}</h3><p>${product.type}</p><span class="product-price">${money(product.price)}</span>
    </div>
    <button class="add-button" data-add="${product.id}">Add to bag</button>`;
  card.querySelector(".wishlist").addEventListener("click", event => {
    event.stopPropagation();
    event.currentTarget.classList.toggle("saved");
    event.currentTarget.textContent = event.currentTarget.classList.contains("saved") ? "♥" : "♡";
    showToast(event.currentTarget.classList.contains("saved") ? "Saved to your wishlist" : "Removed from wishlist");
  });
  card.querySelector(".product-visual").addEventListener("click", () => showToast(`${product.name} · ${product.type} · ${money(product.price)}`));
  card.querySelector(".product-visual").addEventListener("keydown", event => {
    if (event.key === "Enter" || event.key === " ") showToast(`${product.name} · ${product.type} · ${money(product.price)}`);
  });
  card.querySelector("[data-add]").addEventListener("click", () => addToBag(product));
  return card;
}

function renderProducts(filter = activeFilter, query = "") {
  activeFilter = filter;
  const normalized = query.trim().toLowerCase();
  const visible = products.filter(product => {
    const inCategory = filter === "all" || product.category === filter;
    const inSearch = !normalized || `${product.name} ${product.category} ${product.type}`.toLowerCase().includes(normalized);
    return inCategory && inSearch;
  });
  grid.innerHTML = "";
  visible.forEach(product => grid.append(productCard(product)));
  if (!visible.length) {
    const message = filter === "kids"
      ? "The first Kids capsule is being sourced and quality-tested. It will appear here after supplier approval."
      : "No pieces match that search yet. Try “dress”, “women” or “jewellery”.";
    grid.innerHTML = `<p>${message}</p>`;
  }
}

function setFilter(filter) {
  document.querySelectorAll(".filter").forEach(button => button.classList.toggle("active", button.dataset.filter === filter));
  renderProducts(filter);
}

function addToBag(product) {
  bag.push(product);
  updateBag();
  showToast(`${product.name} added to your bag`);
}

function updateBag() {
  document.querySelector("#bagCount").textContent = bag.length;
  const items = document.querySelector("#bagItems");
  const empty = document.querySelector("#bagEmpty");
  const summary = document.querySelector("#bagSummary");
  items.innerHTML = "";
  bag.forEach((product, index) => {
    const item = document.createElement("div");
    item.className = "bag-item";
    const thumb = `<div class="bag-thumb" aria-hidden="true">${product.name.charAt(0)}</div>`;
    const itemPrice = product.price ? money(product.price) : "After inspection";
    item.innerHTML = `${thumb}<div><h3>${product.name}</h3><p>${product.type}</p><strong>${itemPrice}</strong></div><button class="remove-item" aria-label="Remove ${product.name}" data-remove="${index}">×</button>`;
    items.append(item);
  });
  empty.hidden = bag.length > 0;
  summary.hidden = bag.length === 0;
  const subtotal = bag.reduce((sum, item) => sum + item.price, 0);
  document.querySelector("#bagSubtotal").textContent = subtotal ? money(subtotal) : "After inspection";
  items.querySelectorAll("[data-remove]").forEach(button => button.addEventListener("click", () => {
    bag.splice(Number(button.dataset.remove), 1);
    updateBag();
  }));
}

function showToast(message) {
  toast.textContent = message;
  toast.classList.add("show");
  clearTimeout(showToast.timer);
  showToast.timer = setTimeout(() => toast.classList.remove("show"), 2600);
}

function openLayer(element) {
  closeLayers();
  overlay.hidden = false;
  element.classList.add("open");
  element.setAttribute("aria-hidden", "false");
  document.body.classList.add("locked");
  const focusable = element.querySelector("input, select, button, a");
  if (focusable) setTimeout(() => focusable.focus(), 80);
}

function closeLayers() {
  [bagDrawer, sellModal, searchPanel].forEach(element => {
    element.classList.remove("open");
    element.setAttribute("aria-hidden", "true");
  });
  document.querySelector("#mainNav").classList.remove("open");
  document.querySelector("#menuButton").setAttribute("aria-expanded", "false");
  overlay.hidden = true;
  document.body.classList.remove("locked");
}

document.querySelectorAll(".filter").forEach(button => button.addEventListener("click", () => setFilter(button.dataset.filter)));
document.querySelectorAll("[data-filter-link]").forEach(link => link.addEventListener("click", () => {
  setFilter(link.dataset.filterLink);
  document.querySelector("#mainNav").classList.remove("open");
}));
document.querySelector("#bagButton").addEventListener("click", () => openLayer(bagDrawer));
document.querySelector("#searchButton").addEventListener("click", () => openLayer(searchPanel));
document.querySelector("#sellButton").addEventListener("click", () => openLayer(sellModal));
document.querySelector("[data-add-relove]").addEventListener("click", () => addToBag(relovePiece));
document.querySelector("#menuButton").addEventListener("click", event => {
  const nav = document.querySelector("#mainNav");
  const isOpen = nav.classList.toggle("open");
  event.currentTarget.setAttribute("aria-expanded", String(isOpen));
  overlay.hidden = !isOpen;
});
document.querySelectorAll("[data-close]").forEach(button => button.addEventListener("click", closeLayers));
overlay.addEventListener("click", closeLayers);
document.addEventListener("keydown", event => { if (event.key === "Escape") closeLayers(); });

document.querySelector("#searchInput").addEventListener("input", event => {
  const query = event.target.value;
  const count = products.filter(p => `${p.name} ${p.type}`.toLowerCase().includes(query.toLowerCase())).length;
  document.querySelector("#searchResults").textContent = query ? `${count} matching piece${count === 1 ? "" : "s"}` : "Search women, men, kids and jewellery";
});
document.querySelector("#searchInput").addEventListener("keydown", event => {
  if (event.key === "Enter") {
    renderProducts("all", event.currentTarget.value);
    closeLayers();
    document.querySelector("#new").scrollIntoView();
  }
});

document.querySelector("#newsletterForm").addEventListener("submit", event => {
  event.preventDefault();
  showToast("You’re on the Dyaana preview list");
  event.currentTarget.reset();
});
document.querySelector("#reloveForm").addEventListener("submit", event => {
  event.preventDefault();
  closeLayers();
  showToast("Dress details saved for initial review");
  event.currentTarget.reset();
});
document.querySelector("#checkoutButton").addEventListener("click", () => showToast("Secure payment integration will be connected before launch"));

renderProducts();
updateBag();
